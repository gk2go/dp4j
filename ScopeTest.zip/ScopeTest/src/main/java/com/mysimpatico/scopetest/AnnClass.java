/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mysimpatico.scopetest;

/**
 *
 * @author simpatico
 */
public class AnnClass {

    @SampleAnn
    public void helloWorld(){

    }
}

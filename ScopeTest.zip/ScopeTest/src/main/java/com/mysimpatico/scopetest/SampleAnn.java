/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mysimpatico.scopetest;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 *
 * @author simpatico
 */
@Target(ElementType.METHOD)
public @interface SampleAnn {

}

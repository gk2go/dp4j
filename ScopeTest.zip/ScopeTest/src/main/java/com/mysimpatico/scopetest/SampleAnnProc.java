package com.mysimpatico.scopetest;

import com.sun.source.util.TreePath;
import java.util.*;
import javax.annotation.processing.*;
import javax.lang.model.*;
import javax.lang.model.element.TypeElement;
import com.sun.source.util.Trees;
import javax.lang.model.element.Element;

/**
 * Hello world!
 *
 */
@SupportedAnnotationTypes("com.mysimpatico.scopetest.SampleAnn")
@SupportedSourceVersion(SourceVersion.RELEASE_6)
public class SampleAnnProc extends AbstractProcessor {

    protected Trees trees;

    @Override
    public void init(ProcessingEnvironment processingEnv) {
        super.init(processingEnv);
        trees = Trees.instance(processingEnv);
    }

    protected Set<? extends Element> getElementsAnnotated(final RoundEnvironment roundEnv, Set<? extends TypeElement> annotations) {
        final Set<Element> annotatatedElements = new HashSet<Element>();
        for (TypeElement ann : annotations) {
            final Set<? extends Element> annElements = roundEnv.getElementsAnnotatedWith(ann);
            annotatatedElements.addAll(annElements);
        }
        return annotatatedElements;
    }

    @Override
    public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
        for (final Element e : getElementsAnnotated(roundEnv, annotations)) {
            final TreePath treePath = trees.getPath(e);
            treePath.getClass(); //so it's not null
            com.sun.source.tree.Scope scope = trees.getScope(treePath);
        }
        return true;
    }
}

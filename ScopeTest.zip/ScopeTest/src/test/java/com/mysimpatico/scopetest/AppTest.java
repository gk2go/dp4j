package com.mysimpatico.scopetest;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import java.io.*;
import java.util.*;
import javax.annotation.processing.*;
import javax.tools.JavaCompiler.*;
import javax.tools.*;
/**
 * Unit test for simple App.
 */
public class AppTest
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( AppTest.class );
    }

         static File getFile(final File dir, final String... dirs) {
        File ret = dir;
        for (String dir1 : dirs) {
            if (ret == null) {
                ret = new File(dir1);
            } else {
                ret = new File(ret.getPath(), dir1);
            }
        }
        return ret;
    }

    /**
     * Rigourous Test :-)
     */
    public void testApp()
    {
         final JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();

        final File workingdir = new File(System.getProperty("user.dir"));
        final File src = getFile(workingdir, "src", "main", "java", "com",  "mysimpatico", "scopetest");
        final File annotatedFile = new File(src, "AnnClass.java");
        final StandardJavaFileManager fm = compiler.getStandardFileManager(null, null, null);
        CompilationTask task = compiler.getTask(null, null, null, Arrays.asList("-verbose"), null, fm.getJavaFileObjectsFromFiles(Arrays.asList(annotatedFile)));

        task.setProcessors(Arrays.<Processor>asList(new SampleAnnProc()));
        task.call();
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.dp4j;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
/**
 *
 * @author simpatico
 */

//FIXME: could not create @component in Windows

@Documented
@Target(ElementType.TYPE)
public @interface Decorator {

}

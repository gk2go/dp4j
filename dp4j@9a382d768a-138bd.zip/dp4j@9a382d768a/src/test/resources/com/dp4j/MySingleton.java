import com.dp4j.*;

@Singleton
class MySingleton{
}


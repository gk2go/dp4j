
package com.dp4j;

import org.junit.Test;
public final class SingletonTest {

    @Test
    public void test() {
//        SingletonImpl singletonImpl = SingletonImpl.getInstance();
    }
}



